# from django.views.generic import ListView
# from django.views.generic import DetailView
# from django.views.generic import TemplateView

# from .models import Book
# from django.urls import reverse_lazy
# from django.views.generic import (
#     ListView,
#     DetailView,
#     CreateView,
#     UpdateView,
#     DeleteView,
#     TemplateView,
# )

# from .forms import BookForm
# from .models import Book
# from django.contrib.auth.mixins import LoginRequiredMixin
# from django.contrib.auth import login
# from django.contrib.auth.forms import UserCreationForm
# from django.urls import reverse_lazy
# from django.views.generic import CreateView
# from .forms import RegisterForm
# from django.contrib.auth.mixins import PermissionRequiredMixin
# from django.contrib.auth.mixins import UserPassesTestMixin

# class RegisterView(CreateView):
#     form_class = RegisterForm
#     template_name = "registration/register.html"
#     success_url = reverse_lazy("home")

#     def form_valid(self, form):
#         response = super().form_valid(form)
#         login(self.request, self.object)
#         return response


# class HomeView(TemplateView):

#     template_name = "books/home.html"


# class BookListView(ListView):

#     model = Book

#     context_object_name = "books"


# class BookDetailView(DetailView):

#     model = Book

#     context_object_name = "book"


# class BookCreateView(
#     PermissionRequiredMixin,
#     CreateView,
# ):
#     permission_required = "books.add_book"
#     model = Book
#     form_class = BookForm
#     success_url = reverse_lazy("book-list")


# class BookUpdateView(
#     UserPassesTestMixin,
#     UpdateView,
# ):

#     model = Book
#     fields = "__all__"
#     def test_func(self):
#         return self.request.user.is_staff


# class BookDeleteView(
#     PermissionRequiredMixin,
#     DeleteView,
# ):
#     permission_required = "books.delete_book"
#     model = Book
#     success_url = reverse_lazy("book-list")


from django.views.generic import ListView
from django.views.generic import DetailView
from django.views.generic import TemplateView
from django.views.decorators.cache import cache_page
from django.views.decorators.vary import vary_on_headers, vary_on_cookie
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.core.cache.utils import make_template_fragment_key

from .models import Book
from django.urls import reverse_lazy
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
    TemplateView,
)

from .forms import BookForm
from .models import Book
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views.generic import CreateView
from .forms import RegisterForm
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.contrib.auth.mixins import UserPassesTestMixin
import logging

logger = logging.getLogger(__name__)


class RegisterView(CreateView):
    form_class = RegisterForm
    template_name = "registration/register.html"
    success_url = reverse_lazy("home")

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)
        # Invalidate any cached pages after new registration
        cache.delete('home_page_cache')
        return response


class HomeView(TemplateView):
    template_name = "books/home.html"
    
    @method_decorator(cache_page(60 * 15))  # Cache for 15 minutes
    @method_decorator(vary_on_headers('User-Agent'))  # Vary cache based on user agent
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Cache expensive queries in the context
        cache_key = 'home_stats'
        stats = cache.get(cache_key)
        
        if stats is None:
            # Perform expensive database queries
            stats = {
                'total_books': Book.objects.count(),
                'recent_books': Book.objects.order_by('-created_at')[:5],
                'popular_books': Book.objects.filter(rating__gte=4.0)[:5],
            }
            cache.set(cache_key, stats, timeout=3600)  # Cache for 1 hour
            logger.info("Home stats cached")
        else:
            logger.info("Home stats retrieved from cache")
        
        context.update(stats)
        return context


class BookListView(ListView):
    model = Book
    context_object_name = "books"
    paginate_by = 20  # Add pagination for better performance
    
    @method_decorator(cache_page(60 * 5))  # Cache for 5 minutes
    @method_decorator(vary_on_headers('User-Agent'))
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)
    
    def get_queryset(self):
        # Try to get cached queryset
        cache_key = 'book_list_all'
        books = cache.get(cache_key)
        
        if books is None:
            books = super().get_queryset().select_related('author').prefetch_related('categories')
            cache.set(cache_key, books, timeout=300)  # Cache for 5 minutes
            logger.info("Book list cached")
        else:
            logger.info("Book list retrieved from cache")
        
        return books
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Cache additional data
        cache_key = 'book_list_metadata'
        metadata = cache.get(cache_key)
        
        if metadata is None:
            metadata = {
                'total_books': self.model.objects.count(),
                'categories': self.model.objects.values_list('category', flat=True).distinct(),
            }
            cache.set(cache_key, metadata, timeout=3600)
        
        context.update(metadata)
        return context


class BookDetailView(DetailView):
    model = Book
    context_object_name = "book"
    
    @method_decorator(cache_page(60 * 15))  # Cache for 15 minutes
    @method_decorator(vary_on_headers('User-Agent'))
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)
    
    def get_object(self, queryset=None):
        # Cache individual book objects
        pk = self.kwargs.get('pk')
        cache_key = f'book_detail_{pk}'
        book = cache.get(cache_key)
        
        if book is None:
            book = super().get_object(queryset)
            cache.set(cache_key, book, timeout=900)  # Cache for 15 minutes
            logger.info(f"Book {pk} cached")
        else:
            logger.info(f"Book {pk} retrieved from cache")
        
        return book
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book = self.get_object()
        
        # Cache related data
        cache_key = f'book_related_{book.id}'
        related_data = cache.get(cache_key)
        
        if related_data is None:
            related_data = {
                'similar_books': Book.objects.exclude(id=book.id).filter(category=book.category)[:5],
                'reviews': book.reviews.all()[:10],
                'rating': book.reviews.aggregate(avg_rating=models.Avg('rating')) if hasattr(book, 'reviews') else None,
            }
            cache.set(cache_key, related_data, timeout=3600)
        
        context.update(related_data)
        return context


class BookCreateView(
    PermissionRequiredMixin,
    CreateView,
):
    permission_required = "books.add_book"
    model = Book
    form_class = BookForm
    success_url = reverse_lazy("book-list")
    
    def form_valid(self, form):
        response = super().form_valid(form)
        # Invalidate cache when new book is added
        cache.delete('book_list_all')
        cache.delete('home_stats')
        # Delete all book detail caches (you might want a more targeted approach)
        cache.delete_pattern('book_detail_*')
        logger.info(f"Cache invalidated after creating book {self.object.id}")
        return response


class BookUpdateView(
    UserPassesTestMixin,
    UpdateView,
):
    model = Book
    fields = "__all__"
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        response = super().form_valid(form)
        # Invalidate cache for this specific book
        cache_key = f'book_detail_{self.object.id}'
        cache.delete(cache_key)
        cache.delete('book_list_all')
        cache.delete('home_stats')
        logger.info(f"Cache invalidated for book {self.object.id}")
        return response


class BookDeleteView(
    PermissionRequiredMixin,
    DeleteView,
):
    permission_required = "books.delete_book"
    model = Book
    success_url = reverse_lazy("book-list")
    
    def delete(self, request, *args, **kwargs):
        # Get book id before deletion
        book_id = self.get_object().id
        response = super().delete(request, *args, **kwargs)
        # Invalidate cache after deletion
        cache_key = f'book_detail_{book_id}'
        cache.delete(cache_key)
        cache.delete('book_list_all')
        cache.delete('home_stats')
        logger.info(f"Cache invalidated after deleting book {book_id}")
        return response


# Additional utility methods for cache management
class CacheInvalidationMixin:
    """Mixin to invalidate cache on create/update/delete operations"""
    
    cache_keys_to_invalidate = ['book_list_all', 'home_stats']
    
    def invalidate_cache(self, *args, **kwargs):
        for key in self.cache_keys_to_invalidate:
            cache.delete(key)
        # Invalidate pattern-based caches
        cache.delete_pattern('book_detail_*')
        logger.info(f"Cache invalidated for keys: {self.cache_keys_to_invalidate}")
    
    def form_valid(self, form):
        response = super().form_valid(form)
        self.invalidate_cache()
        return response
    
    def delete(self, request, *args, **kwargs):
        response = super().delete(request, *args, **kwargs)
        self.invalidate_cache()
        return response


# Example of using the mixin (optional alternative implementation)
class BookCreateViewWithMixin(
    PermissionRequiredMixin,
    CacheInvalidationMixin,
    CreateView,
):
    permission_required = "books.add_book"
    model = Book
    form_class = BookForm
    success_url = reverse_lazy("book-list")